package tech.twentytwobits.fastnotes

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import tech.twentytwobits.fastnotes.NotesData.NotesDatabase

class MainActivity : AppCompatActivity() {

    private var notesDatabase: NotesDatabase? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        notesDatabase = NotesDatabase.getInstance(this)

        // Llamar el activity de agregar notas desde el FAB
        fabAgregarNota.setOnClickListener {
            startActivity(Intent(this, NoteAddActivity::class.java))
        }
    }
}
